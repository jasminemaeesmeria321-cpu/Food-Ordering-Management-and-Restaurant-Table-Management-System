(() => {
'use strict';

const RAW = {
  menu: [
    { id: 'salmon', name: 'Salmon rice bowl', cat: 'Mains', desc: 'Teriyaki salmon, avocado, sesame', price: 385, tag: 'Bestseller', img: 'images/salmonrice.jpeg' },
    { id: 'pesto', name: 'Garden pesto pasta', cat: 'Mains', desc: 'Basil pesto, cherry tomato, parmesan', price: 320, tag: 'Vegetarian', img: 'images/pestopasta.jpeg' },
    { id: 'burger', name: 'Crispy chicken burger', cat: 'Mains', desc: 'Golden chicken, slaw, house sauce', price: 295, tag: 'Popular', img: 'images/chickenburger.jpeg' },
    { id: 'fries', name: 'Truffle fries', cat: 'Sides', desc: 'Parmesan, parsley, truffle aioli', price: 180, tag: 'Sides', img: 'images/trufflefries.jpeg' },
    { id: 'soda', name: 'Strawberry soda', cat: 'Drinks', desc: 'Fresh strawberry, sparkling water', price: 120, tag: 'Drinks', img: 'images/strawberrysoda.jpeg' },
    { id: 'cheesecake', name: 'Berry cheesecake', cat: 'Desserts', desc: 'Vanilla cream, seasonal berries', price: 210, tag: 'Dessert', img: 'images/berrycheesecake.jpeg' }
  ],
  tables: [
    { id: 'T01', seats: 4, status: 'occupied', guest: 'Noah Miller', party: 2, seatedMins: 35, server: 'Lily Morgan', orderId: 1037 },
    { id: 'T02', seats: 4, status: 'occupied', guest: 'James Lee', party: 3, seatedMins: 25, server: 'Ben Carter', orderId: 1039 },
    { id: 'T03', seats: 4, status: 'occupied', guest: 'Oliver Chen', party: 2, seatedMins: 7, server: 'Lily Morgan', orderId: 1042 },
    { id: 'T04', seats: 4, status: 'reserved', reservation: { name: 'Dwigth Ramos', guests: 2, time: '13:00' } },
    { id: 'T05', seats: 4, status: 'available' },
    { id: 'T06', seats: 4, status: 'occupied', guest: 'Isabella Cruz', party: 2, seatedMins: 30, server: 'Ana Reyes', orderId: 1038 },
    { id: 'T07', seats: 4, status: 'occupied', guest: 'Sophie Kim', party: 2, seatedMins: 13, server: 'Ben Carter', orderId: 1041 },
    { id: 'T08', seats: 4, status: 'occupied', guest: 'Mia Johnson', party: 4, seatedMins: 43, server: 'Ana Reyes', orderId: 1036 },
    { id: 'T09', seats: 4, status: 'reserved', reservation: { name: 'Blake Ramos', guests: 4, time: '13:30' } },
    { id: 'T10', seats: 4, status: 'available' },
    { id: 'T11', seats: 4, status: 'available' },
    { id: 'T12', seats: 4, status: 'available' }
  ],
  orders: [
    { id: 1042, minsAgo: 7, guest: 'Oliver Chen', tableId: 'T03', type: 'dine-in', items: { salmon: 2, fries: 1, soda: 1 }, status: 'preparing', paid: false, note: '' },
    { id: 1041, minsAgo: 13, guest: 'Sophie Kim', tableId: 'T07', type: 'dine-in', items: { burger: 1, pesto: 1, soda: 1 }, status: 'ready', paid: false, note: '' },
    { id: 1040, minsAgo: 19, guest: 'Ava Thompson', tableId: null, type: 'takeaway', items: { burger: 1, cheesecake: 1 }, status: 'new', paid: true, note: '' },
    { id: 1039, minsAgo: 25, guest: 'James Lee', tableId: 'T02', type: 'dine-in', items: { pesto: 2, burger: 2, fries: 1 }, status: 'preparing', paid: false, note: '' },
    { id: 1038, minsAgo: 30, guest: 'Isabella Cruz', tableId: 'T06', type: 'dine-in', items: { salmon: 1, pesto: 1, soda: 1 }, status: 'preparing', paid: false, note: '' },
    { id: 1037, minsAgo: 35, guest: 'Noah Miller', tableId: 'T01', type: 'dine-in', items: { burger: 1, soda: 1 }, status: 'ready', paid: false, note: '' },
    { id: 1036, minsAgo: 43, guest: 'Mia Johnson', tableId: 'T08', type: 'dine-in', items: { salmon: 2, fries: 1, cheesecake: 1 }, status: 'completed', paid: true, note: '' },
    { id: 1035, minsAgo: 49, guest: 'Ethan Davis', tableId: null, type: 'takeaway', items: { pesto: 1, soda: 1 }, status: 'completed', paid: true, note: '' }
  ],
  expenses: [
    { desc: 'Fresh produce delivery', cat: 'Ingredients', daysAgo: 0, amount: 15200 },
    { desc: 'Morning team wages', cat: 'Payroll', daysAgo: 0, amount: 9800 },
    { desc: 'Energy & water', cat: 'Utilities', daysAgo: 0, amount: 2600 },
    { desc: 'Weekly seafood delivery', cat: 'Ingredients', daysAgo: 1, amount: 8400 }
  ],
  hourly: [2400, 4800, 9600, 10200, 6100, 3300, 1200, 800],
  completedBase: 46,
  yesterdayRevenue: 34100,
  sold: { salmon: 18, pesto: 12, fries: 10, burger: 7, soda: 15, cheesecake: 6 },
  nextOrderId: 1043,
  profile: null
};

const KEY = 'minwon_state_v1', TAX = 0.1, MIN = 60000, DAY = 864e5;
const FLOW = ['new', 'preparing', 'ready', 'completed'];
const SERVERS = ['Lily Morgan', 'Ben Carter', 'Ana Reyes'];
const SB = {
  new: ['badge-pink', '', 'New'], preparing: ['badge-blue', 'dot-blue', 'Preparing'],
  ready: ['badge-green', 'dot-green', 'Ready'], completed: ['badge-green', 'dot-green', 'Completed'],
  cancelled: ['badge-gold', 'dot-gold', 'Cancelled'], available: ['badge-blue', 'dot-blue', 'Available'],
  occupied: ['badge-pink', '', 'Occupied'], reserved: ['badge-gold', 'dot-gold', 'Reserved']
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const peso = n => '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pesoS = n => '₱' + Math.round(n).toLocaleString('en-PH');
const kfmt = n => n >= 1000 ? '₱' + +(n / 1000).toFixed(1) + 'k' : '₱' + Math.round(n);
const clock = ts => new Date(ts).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
const md = d => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
const hhmm = t => { const [h, m] = t.split(':').map(Number); return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
const badge = k => { const [b, d, l] = SB[k]; return `<span class="badge ${b}"><span class="dot ${d}"></span>${l}</span>`; };
const initials = n => n.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('') || 'WG';
const blankDraft = () => ({ items: {}, type: 'dine-in', tableId: '', guests: 2, note: '', guestName: '', phone: '', editOrderId: null });

let S, menuEl;
const ui = { tab: 'all', q: '', type: 'all', unpaid: false, page: 1, cat: 'All items', sel: 'T03', view: 'floor', days: 30 };

/*  data  */
function hydrate(raw) {
  const now = Date.now(), mid = new Date().setHours(0, 0, 0, 0), s = JSON.parse(JSON.stringify(raw));
  s.orders.forEach(o => { o.createdAt = now - o.minsAgo * MIN; delete o.minsAgo; });
  s.tables.forEach(t => { if (t.seatedMins != null) t.seatedAt = now - t.seatedMins * MIN; delete t.seatedMins; });
  s.expenses.forEach(e => { e.ts = mid - e.daysAgo * DAY + 9 * 36e5; delete e.daysAgo; });
  s.draft = blankDraft();
  return s;
}
async function load() {
  try { const s = JSON.parse(localStorage.getItem(KEY)); if (s && s.tables) return s; } catch (e) {}
  let raw = null;
  try { const r = await fetch('data.json', { cache: 'no-store' }); if (r.ok) raw = await r.json(); } catch (e) {}
  return hydrate(raw || RAW);
}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
const commit = () => { save(); refresh(); };
window.resetRestaurantData = () => { localStorage.removeItem(KEY); location.reload(); };

const T = id => S.tables.find(t => t.id === id);
const O = id => S.orders.find(o => o.id === id);
const M = id => S.menu.find(m => m.id === id);
const lines = o => Object.entries(o.items).filter(([, q]) => q > 0).map(([id, q]) => [M(id), q]).filter(([m]) => m);
const count = o => lines(o).reduce((a, [, q]) => a + q, 0);
const subtotal = o => lines(o).reduce((a, [m, q]) => a + m.price * q, 0);
const total = o => subtotal(o) * (1 + TAX);
const active = o => ['new', 'preparing', 'ready'].includes(o.status);
const revenueToday = () => S.hourly.reduce((a, b) => a + b, 0);
const midnight = () => new Date().setHours(0, 0, 0, 0);
const expensesToday = () => S.expenses.filter(e => e.ts >= midnight()).reduce((a, e) => a + e.amount, 0);
const completedCount = () => S.completedBase + S.orders.filter(o => o.status === 'completed').length;
const ordersTotal = () => S.completedBase + S.orders.length;
const byStatus = st => S.tables.filter(t => t.status === st);
const mins = ts => Math.max(0, Math.round((Date.now() - ts) / MIN));
const resList = () => byStatus('reserved').filter(t => t.reservation).sort((a, b) => a.reservation.time.localeCompare(b.reservation.time));

function release(t) {
  t.status = 'available';
  ['guest', 'party', 'seatedAt', 'server', 'orderId', 'reservation'].forEach(k => delete t[k]);
}
function afterChange(o) {
  if (o.status === 'completed' && o.paid && o.tableId) { const t = T(o.tableId); if (t && t.orderId === o.id) release(t); }
}
function addRevenue(n) {
  const h = new Date().getHours();
  S.hourly[Math.min(7, Math.max(0, h - 10))] += n;
}
function pay(o) {
  if (o.paid) return;
  o.paid = true; addRevenue(Math.round(total(o))); afterChange(o); commit();
}
function advance(o) {
  const i = FLOW.indexOf(o.status);
  if (i < 0 || i === FLOW.length - 1) return;
  o.status = FLOW[i + 1]; afterChange(o); commit();
}
function cancelOrder(o) {
  o.status = 'cancelled';
  const t = o.tableId && T(o.tableId);
  if (t && t.orderId === o.id) release(t);
  commit();
}

/*  ui helpers  */
(function injectCss() {
  const st = document.createElement('style');
  st.textContent = `.mw-toast{position:fixed;right:24px;bottom:24px;background:var(--ink);color:#fff;padding:14px 20px;border-radius:14px;font-size:14px;z-index:99;box-shadow:0 14px 40px rgba(31,42,74,.25);transition:opacity .3s}
.mw-overlay{position:fixed;inset:0;background:rgba(31,42,74,.4);display:grid;place-items:center;z-index:90;padding:20px}
.mw-modal{background:#fff;border-radius:24px;padding:28px;width:min(440px,100%);max-height:90vh;overflow:auto}
.mw-modal h2{font-family:var(--font-display);font-weight:400;font-size:30px}
.mw-modal label{display:block;margin-top:14px;font-size:12px;color:var(--ink-soft)}
.mw-modal input,.mw-modal select{width:100%;height:46px;margin-top:6px;padding:0 14px;border:1px solid var(--line);border-radius:12px;font:400 14px var(--font-body);color:var(--ink);background:#fff}
.mw-actions{display:flex;gap:12px;justify-content:flex-end;margin-top:24px}
.mw-actions .btn{height:44px;padding:0 22px}
.mw-menu{position:fixed;z-index:80;min-width:190px;padding:6px;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 14px 40px rgba(31,42,74,.16)}
.mw-menu button{display:block;width:100%;padding:10px 14px;border:0;background:none;border-radius:9px;text-align:left;font:500 13px var(--font-body);color:var(--ink);cursor:pointer}
.mw-menu button:hover{background:#f1f3f9}
.mw-list{margin-top:22px;width:100%;border-collapse:collapse;font-size:13px}
.mw-list th{padding:8px;text-align:left;font-weight:400;font-size:11px;text-transform:uppercase;color:var(--ink-soft)}
.mw-list td{padding:12px 8px;border-top:1px solid var(--line)}
.mw-list tr[data-t]{cursor:pointer}.mw-list tr.sel{background:#f9faff}
.mw-empty{padding:28px;text-align:center;color:var(--ink-soft);font-size:14px}`;
  document.head.appendChild(st);
})();

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'mw-toast'; t.textContent = msg; document.body.appendChild(t);
  setTimeout(() => { t.style.opacity = 0; setTimeout(() => t.remove(), 300); }, 2400);
}
function modal(title, body, btns) {
  const ov = document.createElement('div');
  ov.className = 'mw-overlay';
  ov.innerHTML = `<div class="mw-modal" role="dialog" aria-modal="true"><h2>${title}</h2>${body}<div class="mw-actions"></div></div>`;
  const box = $('.mw-modal', ov), act = $('.mw-actions', ov), close = () => ov.remove();
  btns.forEach(b => {
    const el = document.createElement('button');
    el.type = 'button'; el.className = 'btn ' + (b.primary ? 'btn-primary' : 'btn-outline'); el.textContent = b.label;
    el.onclick = () => { if (!b.onClick || b.onClick(box) !== false) close(); };
    act.appendChild(el);
  });
  ov.addEventListener('mousedown', e => { if (e.target === ov) close(); });
  document.body.appendChild(ov);
  const f = $('input,select', box); if (f) f.focus();
  return close;
}
const closeMenu = () => { if (menuEl) menuEl.remove(); menuEl = null; };
document.addEventListener('click', e => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); }, true);
function openMenu(btn, items) {
  closeMenu();
  const r = btn.getBoundingClientRect();
  menuEl = document.createElement('div');
  menuEl.className = 'mw-menu';
  menuEl.style.top = r.bottom + 4 + 'px'; menuEl.style.right = innerWidth - r.right + 'px';
  items.forEach(i => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = i.label;
    b.onclick = () => { closeMenu(); i.fn(); };
    menuEl.appendChild(b);
  });
  document.body.appendChild(menuEl);
}

function billModal(o) {
  const li = lines(o).map(([m, q]) => `<li style="display:flex;justify-content:space-between;padding:6px 0"><span>${q} × ${esc(m.name)}</span><span>${peso(m.price * q)}</span></li>`).join('');
  const sub = subtotal(o);
  const row = (a, b, big) => `<div style="display:flex;justify-content:space-between;padding:4px 0;${big ? 'font-weight:600;font-size:18px;color:var(--blue-text)' : 'color:var(--ink-soft)'}"><span>${a}</span><span>${b}</span></div>`;
  const canPay = !o.paid && o.status !== 'cancelled';
  const body = `<p style="margin-top:6px;font-size:13px;color:var(--ink-soft)">Order #${o.id} · ${o.tableId || 'Takeaway'} · ${esc(o.guest)}</p>
<ul style="list-style:none;padding:0;margin:16px 0 8px;border-bottom:1px solid var(--line);font-size:14px">${li}</ul>
${row('Subtotal', peso(sub))}${row('Tax (10%)', peso(sub * TAX))}${row('Total', peso(sub * (1 + TAX)), true)}
${canPay ? '<label>Payment method<select id="mw-pay"><option>Cash</option><option>Card</option><option>GCash</option></select></label>' : `<p style="margin-top:14px;color:var(--green)">${o.paid ? 'Paid in full' : 'Order cancelled'}</p>`}`;
  const btns = [{ label: 'Close' }];
  if (canPay) btns.push({ label: 'Collect payment', primary: true, onClick: box => { const m = $('#mw-pay', box).value; pay(o); toast(`${peso(total(o))} collected via ${m}`); } });
  modal('Bill', body, btns);
}

function startEdit(o, tableId) {
  S.draft = blankDraft();
  if (o) { S.draft.editOrderId = o.id; S.draft.tableId = o.tableId || ''; S.draft.type = o.type; S.draft.guests = (T(o.tableId) || {}).party || 2; }
  else if (tableId) S.draft.tableId = tableId;
  save(); location.href = 'neworder.html';
}

function reserveModal(pre) {
  const free = byStatus('available');
  if (!free.length) return toast('No tables are free to reserve right now');
  const d = new Date(Date.now() + 36e5); d.setMinutes(d.getMinutes() < 30 ? 30 : 60, 0, 0);
  const def = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  modal('Add reservation', `<label>Guest name<input id="rv-name" type="text" placeholder="e.g. Emma Wilson"></label>
<label>Guests<select id="rv-g">${[1, 2, 3, 4].map(n => `<option ${n === 2 ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
<label>Time<input id="rv-time" type="time" value="${def}"></label>
<label>Table<select id="rv-t">${free.map(t => `<option value="${t.id}" ${t.id === pre ? 'selected' : ''}>${t.id} · ${t.seats} seats</option>`).join('')}</select></label>`,
    [{ label: 'Cancel' }, {
      label: 'Save reservation', primary: true, onClick: b => {
        const name = $('#rv-name', b).value.trim(), time = $('#rv-time', b).value;
        if (!name || !time) { toast('Please add a name and time'); return false; }
        const t = T($('#rv-t', b).value);
        t.status = 'reserved'; t.reservation = { name, guests: +$('#rv-g', b).value, time };
        ui.sel = t.id; commit(); toast(`${t.id} reserved for ${name}`);
      }
    }]);
}

/*  shared chrome  */
function chrome() {
  const d = new Date(), h = d.getHours(), open = h >= 10 && h < 22;
  $$('.topbar-date').forEach(e => e.textContent = d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }));
  const b = $('.badge-open');
  if (b) { b.className = 'badge badge-open ' + (open ? 'badge-green' : 'badge-pink'); b.innerHTML = `<span class="dot ${open ? 'dot-green' : ''}"></span>${open ? 'Open now' : 'Closed'}`; }
  const g = $('.greeting h1');
  if (g && /^Good (morning|afternoon|evening)/.test(g.textContent)) {
    const w = h < 12 ? 'morning' : h < 18 ? 'afternoon' : 'evening';
    g.firstChild.textContent = `Good ${w}, ${(S.profile && S.profile.first) || 'Minwon'} `;
  }
  const bell = $('.icon-btn[aria-label="Notifications"]');
  if (bell) bell.classList.toggle('has-dot', S.orders.some(o => o.status === 'ready' || o.status === 'new'));
  if (S.profile) {
    const name = `${S.profile.first} ${S.profile.last}`;
    $$('.avatar-white,.avatar-pink').forEach(a => a.textContent = initials(name));
    const n = $('.side-user-text strong'); if (n) n.textContent = name;
  }
}
function bindChrome() {
  const bell = $('.icon-btn[aria-label="Notifications"]');
  if (bell) bell.onclick = () => {
    const r = S.orders.filter(o => o.status === 'ready').length, n = S.orders.filter(o => o.status === 'new').length;
    toast(r || n ? `${r} ready to serve · ${n} new in the kitchen` : 'All caught up. No new alerts.');
  };
  const s = $('.icon-btn[aria-label="Search"]');
  if (s) s.onclick = () => modal('Find an order', '<label>Order number or guest name<input id="mw-q" type="search"></label>',
    [{ label: 'Cancel' }, { label: 'Search', primary: true, onClick: b => { location.href = 'order.html?q=' + encodeURIComponent($('#mw-q', b).value.trim()); } }]);
  $$('a[href="neworder.html"],a[href="new-order.html"],.greeting .btn-primary[href="#"]').forEach(a => {
    if (a.closest('.greeting') || a.closest('.hero')) a.addEventListener('click', e => { e.preventDefault(); startEdit(null); });
  });
  const hp = $('.panel-link[href="#"]'); if (hp && /All orders/.test(hp.textContent)) hp.href = 'order.html';
}

/* index */
function renderIndex() {
  const gs = $('.hero-visual .glance-stats'); if (!gs) return;
  $('strong', gs).textContent = ordersTotal();
  $('.accent', gs).textContent = pesoS(revenueToday());
  const ws = $('.header-actions a'); if (ws) ws.href = 'home.html';
  $$('.hero-buttons a')[1].href = 'neworder.html';
}

/*  home */
function renderHome() {
  if (!$('#stat-revenue')) return;
  const rev = revenueToday(), y = S.yesterdayRevenue, pct = (rev - y) / y * 100;
  const act = S.orders.filter(active).length, occ = byStatus('occupied').length;
  $('#stat-revenue').textContent = peso(rev);
  $('#stat-revenue').nextElementSibling.innerHTML = `<i class="fa-solid fa-arrow-${pct >= 0 ? 'up' : 'down'} btn-arrow-ne"></i>${Math.abs(pct).toFixed(1)}% ${pct >= 0 ? 'more' : 'less'} than yesterday`;
  $('#stat-orders').textContent = ordersTotal();
  $('#stat-orders').nextElementSibling.textContent = `${completedCount()} completed · ${act} active orders`;
  $('#stat-tables').textContent = `${occ} / ${S.tables.length}`;
  $('#stat-tables').nextElementSibling.textContent = `${byStatus('available').length} available · ${byStatus('reserved').length} reserved`;
  $('#stat-average').textContent = pesoS(rev / Math.max(1, completedCount()));
  $('#stat-average').nextElementSibling.textContent = `Based on ${completedCount()} completed orders`;

  const tb = $('#orders-table:not(.data-table) tbody');
  tb.innerHTML = [...S.orders].sort((a, b) => b.createdAt - a.createdAt).slice(0, 4).map(o =>
    `<tr><td><strong>#${o.id}</strong><small>${clock(o.createdAt)}</small></td><td>${o.tableId || 'Takeaway'}</td><td>${count(o)} items</td><td>${badge(o.status)}</td><td class="total">${peso(total(o))}</td></tr>`).join('');

  $('#tables-grid').innerHTML = S.tables.map(t => `<span class="table-tile is-${t.status}">${t.id}</span>`).join('');
  $('.legend').innerHTML = `<li><span class="dot dot-blue"></span>${byStatus('available').length} available</li><li><span class="dot"></span>${occ} occupied</li><li><span class="dot dot-gold"></span>${byStatus('reserved').length} reserved</li>`;
  const nb = $('.next-booking div'), r = resList()[0];
  nb.innerHTML = r ? `<strong>Next: ${esc(r.reservation.name)} · ${r.reservation.guests} guests</strong><small>${hhmm(r.reservation.time)} · Table ${r.id}</small>` : '<strong>No upcoming reservations</strong><small>The dining room is all yours</small>';

  const max = Math.max(...S.hourly, 1), top = Math.max(2000, Math.ceil(max / 2000) * 2000);
  $$('#hourly-chart .bar').forEach((b, i) => {
    b.style.setProperty('--h', S.hourly[i] / top * 100);
    b.className = 'bar' + (S.hourly[i] === max ? ' is-peak' : S.hourly[i] > 0 ? ' is-sales' : '');
    b.title = peso(S.hourly[i]);
  });
  const ax = $$('#hourly-chart .chart-axis span');
  [top, top / 2, 0].forEach((v, i) => ax[i].textContent = kfmt(v));

  const fav = [...S.menu].sort((a, b) => (S.sold[b.id] || 0) - (S.sold[a.id] || 0)).slice(0, 3);
  $('#favorites-list').innerHTML = fav.map((m, i) => `<li><span class="rank ${i ? 'tint-blue' : 'tint-pink'}">0${i + 1}</span><span class="fav-name"><strong>${esc(m.name)}</strong><small>${S.sold[m.id] || 0} sold</small></span><span class="fav-price">${pesoS(m.price)}</span></li>`).join('');
}

/* food orders  */
function filteredOrders() {
  const q = ui.q.toLowerCase().replace('#', '');
  return [...S.orders].sort((a, b) => b.createdAt - a.createdAt).filter(o =>
    (ui.tab === 'all' || (ui.tab === 'active' ? active(o) : o.status === ui.tab)) &&
    (ui.type === 'all' || o.type === ui.type) && (!ui.unpaid || (!o.paid && o.status !== 'cancelled')) &&
    (!q || String(o.id).includes(q) || o.guest.toLowerCase().includes(q)));
}
function renderOrders() {
  const tbl = $('#orders-table.data-table'); if (!tbl) return;
  const st = k => S.orders.filter(o => o.status === k).length;
  $('#count-new').textContent = st('new'); $('#count-preparing').textContent = st('preparing');
  $('#count-ready').textContent = st('ready'); $('#count-completed').textContent = completedCount();
  const counts = { all: ordersTotal(), active: S.orders.filter(active).length, completed: completedCount(), cancelled: st('cancelled') };
  const labels = { all: 'All orders', active: 'Active', completed: 'Completed', cancelled: 'Cancelled' };
  $$('.orders-panel .tab').forEach((t, i) => {
    const k = Object.keys(labels)[i];
    t.innerHTML = `${labels[k]} <span>${counts[k]}</span>`;
    t.classList.toggle('is-active', k === ui.tab); t.setAttribute('aria-selected', k === ui.tab);
  });
  const rows = filteredOrders(), per = 8, pages = Math.max(1, Math.ceil(rows.length / per));
  ui.page = Math.min(ui.page, pages);
  const slice = rows.slice((ui.page - 1) * per, ui.page * per);
  $('tbody', tbl).innerHTML = slice.map(o => `<tr data-o="${o.id}">
<td><input class="check" type="checkbox" aria-label="Select order #${o.id}"></td>
<td><strong>#${o.id}</strong><small>${clock(o.createdAt)}</small></td>
<td><span class="guest"><span class="guest-avatar">${initials(o.guest)}</span>${esc(o.guest)}</span></td>
<td>${o.tableId || 'Takeaway'}</td><td class="muted">${count(o)} items</td><td class="total">${peso(total(o))}</td>
<td>${badge(o.status)}</td><td class="muted">${o.status === 'cancelled' ? '—' : o.paid ? 'Paid' : 'Unpaid'}</td>
<td class="more"><button class="icon-btn" type="button" aria-label="More actions"><i class="fa-solid fa-ellipsis"></i></button></td></tr>`).join('')
    || '<tr><td colspan="9" class="mw-empty">No orders match your filters.</td></tr>';
  const a = rows.length ? (ui.page - 1) * per + 1 : 0, b = (ui.page - 1) * per + slice.length;
  const archived = ui.tab === 'all' && !ui.q && ui.type === 'all' && !ui.unpaid ? ` · ${S.completedBase - S.orders.filter(o => o.status === 'completed').length > 0 ? S.completedBase : 0} earlier orders archived` : '';
  $('.table-foot > span').textContent = `Showing ${a}–${b} of ${rows.length} orders${archived}`;
  $('.pager').innerHTML = `<button type="button" data-p="${ui.page - 1}" aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></button>` +
    Array.from({ length: pages }, (_, i) => `<button type="button" data-p="${i + 1}" class="${i + 1 === ui.page ? 'is-active' : ''}">${i + 1}</button>`).join('') +
    `<button type="button" data-p="${ui.page + 1}" aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></button>`;
  $('thead .check', tbl).checked = false;
  const sync = $('.sync-note'); if (sync) sync.innerHTML = `<i class="fa-solid fa-rotate"></i>Kitchen is up to date · Last synced at ${clock(Date.now())}`;
}
function bindOrders() {
  const tbl = $('#orders-table.data-table'); if (!tbl) return;
  const qp = new URLSearchParams(location.search).get('q');
  const input = $('.search input');
  if (qp) { ui.q = qp; input.value = qp; }
  input.addEventListener('input', () => { ui.q = input.value.trim(); ui.page = 1; renderOrders(); });
  $$('.orders-panel .tab').forEach((t, i) => t.onclick = () => { ui.tab = ['all', 'active', 'completed', 'cancelled'][i]; ui.page = 1; renderOrders(); });
  const [dateB, typeB, filtB] = $$('.toolbar-actions .btn');
  dateB.onclick = () => toast("Showing today's orders");
  typeB.onclick = () => { ui.type = { all: 'dine-in', 'dine-in': 'takeaway', takeaway: 'all' }[ui.type]; typeB.textContent = { all: 'All order types', 'dine-in': 'Dine-in only', takeaway: 'Takeaway only' }[ui.type]; ui.page = 1; renderOrders(); };
  filtB.onclick = () => { ui.unpaid = !ui.unpaid; filtB.innerHTML = `<i class="fa-solid fa-sliders"></i>${ui.unpaid ? 'Unpaid only' : 'Filters'}`; ui.page = 1; renderOrders(); };
  $('.pager').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { ui.page = Math.max(1, +b.dataset.p); renderOrders(); } });
  $('thead .check', tbl).addEventListener('change', e => $$('tbody .check', tbl).forEach(c => { c.checked = e.target.checked; c.closest('tr').classList.toggle('is-selected', c.checked); }));
  tbl.addEventListener('change', e => { if (e.target.matches('tbody .check')) e.target.closest('tr').classList.toggle('is-selected', e.target.checked); });
  tbl.addEventListener('click', e => {
    const btn = e.target.closest('.more .icon-btn'); if (!btn) return;
    const o = O(+btn.closest('tr').dataset.o), items = [];
    const nxt = { new: 'Start preparing', preparing: 'Mark as ready', ready: 'Mark as completed' }[o.status];
    if (nxt) items.push({ label: nxt, fn: () => { advance(o); toast(`Order #${o.id} is now ${SB[o.status][2].toLowerCase()}`); } });
    items.push({ label: o.paid || o.status === 'cancelled' ? 'View bill' : 'Collect payment', fn: () => billModal(o) });
    if (active(o)) items.push({ label: 'Add items', fn: () => startEdit(o) }, { label: 'Cancel order', fn: () => { if (confirm(`Cancel order #${o.id}?`)) { cancelOrder(o); toast(`Order #${o.id} cancelled`); } } });
    openMenu(btn, items);
  });
}

/*new order */
function renderMenu() {
  const grid = $('#menu-grid'); if (!grid) return;
  const d = S.draft, q = ui.q.toLowerCase();
  const items = S.menu.filter(m => (ui.cat === 'All items' || m.cat === ui.cat) && (!q || (m.name + m.desc).toLowerCase().includes(q)));
  grid.innerHTML = items.map(m => {
    const n = d.items[m.id] || 0;
    const ctl = n ? `<div class="stepper"><button type="button" data-a="dec" data-id="${m.id}" aria-label="Decrease ${esc(m.name)}"><i class="fa-solid fa-minus"></i></button><span>${n}</span><button type="button" data-a="inc" data-id="${m.id}" aria-label="Increase ${esc(m.name)}"><i class="fa-solid fa-plus"></i></button></div>`
      : `<button class="add-btn" type="button" data-a="inc" data-id="${m.id}" aria-label="Add ${esc(m.name)}"><i class="fa-solid fa-plus"></i></button>`;
    return `<article class="menu-card ${n ? 'is-selected' : ''}"><div class="menu-media"><img src="${m.img}" alt=""></div><div class="menu-body"><span class="menu-tag ${m.tag === 'Bestseller' ? 'tag-best' : ''}">${esc(m.tag)}</span><h3>${esc(m.name)}</h3><p>${esc(m.desc)}</p><div class="menu-foot"><strong>${peso(m.price)}</strong>${ctl}</div></div></article>`;
  }).join('') || '<p class="mw-empty">No dishes match your search.</p>';
  $('.menu-head span').textContent = `${items.length} of ${S.menu.length} items`;
  renderSummary();
}
function renderSummary() {
  const d = S.draft, edit = d.editOrderId && O(d.editOrderId);
  const free = byStatus('available').map(t => t.id);
  if (d.tableId && !free.includes(d.tableId) && !(edit && edit.tableId === d.tableId)) d.tableId = '';
  if (d.type === 'dine-in' && !d.tableId) d.tableId = free[0] || '';
  const fakeOrder = { items: d.items }, n = count(fakeOrder), sub = subtotal(fakeOrder);
  $('.summary-meta').textContent = edit ? `Adding to order #${edit.id} · ${edit.guest}` : `Order #${S.nextOrderId} · Created by ${(S.profile && S.profile.first) || 'Minwon'}`;
  $$('.segmented button').forEach(b => { const on = b.textContent.trim().toLowerCase().startsWith(d.type === 'dine-in' ? 'dine' : 'take'); b.classList.toggle('is-active', on); b.setAttribute('aria-selected', on); b.disabled = !!edit; });
  const ts = $('#order-table'), opts = free.concat(edit && edit.tableId && !free.includes(edit.tableId) ? [edit.tableId] : []);
  ts.innerHTML = opts.length ? opts.map(id => `<option value="${id}" ${id === d.tableId ? 'selected' : ''}>${id} · ${T(id).status === 'available' ? 'Available' : 'Occupied'}</option>`).join('') : '<option value="">No tables free</option>';
  ts.disabled = d.type !== 'dine-in' || !!edit;
  $('#order-guests').value = `${d.guests} guest${d.guests > 1 ? 's' : ''}`;
  $('.guest-row span').textContent = d.guestName || (edit ? edit.guest : 'Walk-in guest');
  $('.items-label').textContent = `${n} item${n === 1 ? '' : 's'}`;
  $('#order-lines').innerHTML = lines(fakeOrder).map(([m, q]) => `<li><div class="line-name"><strong>${esc(m.name)}</strong><small>${q} × ${peso(m.price)}</small></div><span class="line-total">${peso(m.price * q)}</span><button class="line-remove" type="button" data-id="${m.id}" aria-label="Remove ${esc(m.name)}"><i class="fa-solid fa-xmark"></i></button></li>`).join('') || '<li><small>No items yet. Tap + on a dish to add it.</small></li>';
  $('#order-subtotal').textContent = peso(sub); $('#order-tax').textContent = peso(sub * TAX); $('#order-total').textContent = peso(sub * (1 + TAX));
  save();
}
function bindMenu() {
  const grid = $('#menu-grid'); if (!grid) return;
  const d = () => S.draft;
  $('.note textarea').value = d().note;
  grid.addEventListener('click', e => {
    const b = e.target.closest('button[data-a]'); if (!b) return;
    const id = b.dataset.id, cur = d().items[id] || 0;
    d().items[id] = Math.max(0, cur + (b.dataset.a === 'inc' ? 1 : -1)); renderMenu();
  });
  $('#order-lines').addEventListener('click', e => { const b = e.target.closest('.line-remove'); if (b) { d().items[b.dataset.id] = 0; renderMenu(); } });
  $('.menu-search input').addEventListener('input', e => { ui.q = e.target.value.trim(); renderMenu(); });
  $$('.pill').forEach(p => p.onclick = () => { ui.cat = p.textContent.trim(); $$('.pill').forEach(x => { x.classList.toggle('is-active', x === p); x.setAttribute('aria-selected', x === p); }); renderMenu(); });
  $$('.segmented button').forEach(b => b.onclick = () => { d().type = b.textContent.trim().toLowerCase().startsWith('dine') ? 'dine-in' : 'takeaway'; renderSummary(); });
  $('#order-table').onchange = e => { d().tableId = e.target.value; save(); };
  $('#order-guests').onchange = e => { d().guests = parseInt(e.target.value); save(); };
  $('.note textarea').addEventListener('input', e => { d().note = e.target.value; save(); });
  $('.guest-row a').onclick = e => {
    e.preventDefault();
    modal('Guest details', `<label>Name<input id="g-n" type="text" value="${esc(d().guestName)}"></label><label>Phone<input id="g-p" type="tel" value="${esc(d().phone)}"></label>`,
      [{ label: 'Cancel' }, { label: 'Save', primary: true, onClick: b => { d().guestName = $('#g-n', b).value.trim(); d().phone = $('#g-p', b).value.trim(); renderSummary(); } }]);
  };
  $('.btn-send').onclick = () => {
    const dr = d(), edit = dr.editOrderId && O(dr.editOrderId);
    if (!count({ items: dr.items })) return toast('Add at least one item first');
    if (!edit && dr.type === 'dine-in' && !dr.tableId) return toast('Pick a table for dine-in orders');
    let id;
    if (edit) {
      Object.entries(dr.items).forEach(([k, q]) => { if (q) edit.items[k] = (edit.items[k] || 0) + q; });
      if (dr.note) edit.note = (edit.note ? edit.note + ' · ' : '') + dr.note;
      if (edit.status === 'ready') edit.status = 'preparing';
      id = edit.id;
    } else {
      id = S.nextOrderId++;
      const o = { id, createdAt: Date.now(), guest: dr.guestName || 'Walk-in guest', tableId: dr.type === 'dine-in' ? dr.tableId : null, type: dr.type, items: { ...dr.items }, status: 'new', paid: false, note: dr.note };
      S.orders.push(o);
      if (o.tableId) { const t = T(o.tableId); Object.assign(t, { status: 'occupied', guest: o.guest, party: dr.guests, seatedAt: Date.now(), server: SERVERS[id % 3], orderId: id }); delete t.reservation; }
    }
    Object.entries(dr.items).forEach(([k, q]) => { S.sold[k] = (S.sold[k] || 0) + q; });
    S.draft = blankDraft(); save();
    toast(`Order #${id} sent to the kitchen`);
    setTimeout(() => { location.href = 'order.html'; }, 800);
  };
}

/* table management */
function tableLabel(t) {
  return t.status === 'occupied' ? `${mins(t.seatedAt || Date.now())} min` : t.status === 'reserved' ? hhmm(t.reservation.time) : `${t.seats} seats`;
}
function renderTables() {
  const grid = $('#floor-grid'); if (!grid) return;
  if (!T(ui.sel)) ui.sel = S.tables[0].id;
  const av = byStatus('available').length, oc = byStatus('occupied').length, rs = byStatus('reserved').length, n = S.tables.length, nx = resList()[0];
  $('#tables-total').textContent = n; $('#tables-total').nextElementSibling.textContent = `Main dining · ${S.tables.reduce((a, t) => a + t.seats, 0)} seats`;
  $('#tables-available').textContent = av; $('#tables-occupied').textContent = oc; $('#tables-occupied').nextElementSibling.textContent = `${Math.round(oc / n * 100)}% of the dining room`;
  $('#tables-reserved').textContent = rs; $('#tables-reserved').nextElementSibling.textContent = nx ? `Next arrival at ${hhmm(nx.reservation.time)}` : 'No upcoming arrivals';
  grid.innerHTML = S.tables.map(t => `<button class="floor-table is-${t.status} ${t.id === ui.sel ? 'is-selected' : ''}" type="button" data-t="${t.id}" aria-label="Table ${t.id}"><span class="chair chair-t"></span><span class="chair chair-b"></span><span class="chair chair-l"></span><span class="chair chair-r"></span><strong>${t.id}</strong><small>${tableLabel(t)}</small></button>`).join('');
  const ar = $('.arriving'), rl = resList();
  ar.innerHTML = `<div class="arriving-title"><strong>Arriving soon</strong><small>${rl.length} upcoming reservation${rl.length === 1 ? '' : 's'}</small></div>` +
    rl.map(t => `<div class="arriving-item"><strong>${esc(t.reservation.name)}</strong><small>${hhmm(t.reservation.time)} · ${t.id} · ${t.reservation.guests} guests</small></div>`).join('');
  $$('.view-toggle button').forEach((b, i) => { const on = (i === 0) === (ui.view === 'floor'); b.classList.toggle('is-active', on); b.setAttribute('aria-selected', on); });
  $('.floor').style.display = ui.view === 'floor' ? '' : 'none';
  let lv = $('#list-view');
  if (!lv) { lv = document.createElement('div'); lv.id = 'list-view'; $('.floor').after(lv); }
  lv.style.display = ui.view === 'list' ? '' : 'none';
  lv.innerHTML = `<table class="mw-list"><thead><tr><th>Table</th><th>Status</th><th>Guest</th><th>Party</th><th>Time</th></tr></thead><tbody>${S.tables.map(t => {
    const g = t.status === 'occupied' ? t.guest : t.status === 'reserved' ? t.reservation.name : '—', p = t.status === 'occupied' ? t.party : t.status === 'reserved' ? t.reservation.guests : '—';
    return `<tr data-t="${t.id}" class="${t.id === ui.sel ? 'sel' : ''}"><td><strong>${t.id}</strong></td><td>${badge(t.status)}</td><td>${esc(g)}</td><td>${p}</td><td>${t.status === 'available' ? '—' : tableLabel(t)}</td></tr>`;
  }).join('')}</tbody></table>`;
  renderDetail();
}
function renderDetail() {
  const t = T(ui.sel), el = $('.detail'), o = t.orderId && O(t.orderId);
  let h = `<div class="detail-head"><h2>Table ${t.id}</h2>${badge(t.status)}</div><p class="detail-meta">Main dining · ${t.seats} seats</p>`;
  const info = rows => `<dl class="detail-info">${rows.map(([a, b]) => `<div><dt>${a}</dt><dd>${esc(b)}</dd></div>`).join('')}</dl>`;
  if (t.status === 'occupied') {
    h += info([['Guest', t.guest], ['Party size', `${t.party} guests`], ['Seated at', `${clock(t.seatedAt)} · ${mins(t.seatedAt)} min ago`], ['Server', t.server || '—']]);
    if (o) {
      const sub = subtotal(o);
      h += `<div class="detail-order-head"><strong>Order #${o.id}</strong>${badge(o.status)}</div><ul class="detail-lines" id="detail-lines">${lines(o).map(([m, q]) => `<li><span>${q} × ${esc(m.name)}</span><span>${peso(m.price * q)}</span></li>`).join('')}</ul>
<dl class="detail-totals"><div><dt>Tax (10%)</dt><dd id="detail-tax">${peso(sub * TAX)}</dd></div><div class="detail-total"><dt>${o.paid ? 'Paid' : 'Total bill'}</dt><dd id="detail-total">${peso(sub * (1 + TAX))}</dd></div></dl>
<button class="btn btn-primary btn-block" data-act="add"><i class="fa-solid fa-plus"></i>Add items to order</button>
<button class="btn btn-outline btn-block" data-act="bill"><i class="fa-solid fa-file-invoice-dollar"></i>${o.paid ? 'View bill' : 'View bill &amp; collect payment'}</button>`;
    } else h += `<p class="mw-empty">No order yet for this table.</p><button class="btn btn-primary btn-block" data-act="add"><i class="fa-solid fa-plus"></i>Create order</button>`;
    h += `<div class="detail-links"><a href="#" data-act="move">Move table</a><a class="muted" href="#" data-act="free">Mark as available</a></div>`;
  } else if (t.status === 'reserved') {
    const r = t.reservation;
    h += info([['Guest', r.name], ['Party size', `${r.guests} guests`], ['Arrival', hhmm(r.time)]]) +
      `<button class="btn btn-primary btn-block" data-act="seat"><i class="fa-solid fa-user-group"></i>Seat guests now</button><div class="detail-links"><a href="#" data-act="cancelres">Cancel reservation</a></div>`;
  } else {
    h += `<p class="mw-empty">This table is ready to welcome new guests.</p>
<button class="btn btn-primary btn-block" data-act="add"><i class="fa-solid fa-plus"></i>Create order</button>
<button class="btn btn-outline btn-block" data-act="reserve"><i class="fa-regular fa-calendar-check"></i>Reserve table</button>`;
  }
  el.innerHTML = h;
}
function bindTables() {
  const grid = $('#floor-grid'); if (!grid) return;
  const pick = e => { const b = e.target.closest('[data-t]'); if (b) { ui.sel = b.dataset.t; renderTables(); } };
  grid.addEventListener('click', pick);
  $('.floor').parentNode.addEventListener('click', e => { if (e.target.closest('#list-view')) pick(e); });
  $$('.view-toggle button').forEach((b, i) => b.onclick = () => { ui.view = i ? 'list' : 'floor'; renderTables(); });
  $('.greeting .btn-primary').addEventListener('click', e => { e.preventDefault(); reserveModal(); });
  $('.detail').addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    e.preventDefault();
    const t = T(ui.sel), o = t.orderId && O(t.orderId), a = b.dataset.act;
    if (a === 'add') startEdit(o, t.id);
    else if (a === 'bill') billModal(o);
    else if (a === 'reserve') reserveModal(t.id);
    else if (a === 'cancelres') { release(t); commit(); toast('Reservation cancelled'); }
    else if (a === 'seat') {
      const r = t.reservation; Object.assign(t, { status: 'occupied', guest: r.name, party: r.guests, seatedAt: Date.now(), server: SERVERS[Math.floor(Math.random() * 3)] });
      delete t.reservation; commit(); toast(`${r.name} seated at ${t.id}`);
    } else if (a === 'free') {
      if (o && !o.paid && o.status !== 'cancelled' && !confirm(`Order #${o.id} is unpaid. Mark ${t.id} as available anyway?`)) return;
      release(t); commit(); toast(`${t.id} is available`);
    } else if (a === 'move') {
      const free = byStatus('available');
      if (!free.length) return toast('No free tables to move to');
      modal('Move table', `<label>Move ${esc(t.guest)} to<select id="mv">${free.map(f => `<option>${f.id}</option>`).join('')}</select></label>`,
        [{ label: 'Cancel' }, {
          label: 'Move', primary: true, onClick: bx => {
            const n = T($('#mv', bx).value);
            Object.assign(n, { status: 'occupied', guest: t.guest, party: t.party, seatedAt: t.seatedAt, server: t.server, orderId: t.orderId });
            if (o) o.tableId = n.id;
            release(t); ui.sel = n.id; commit(); toast(`Moved to ${n.id}`);
          }
        }]);
    }
  });
}

/* profit */
function past(k) {
  const i = 200 - k, wk = new Date(Date.now() - k * DAY).getDay();
  const rev = Math.round((31000 + 6500 * Math.sin(i * .9) + (wk === 5 || wk === 6 ? 7000 : 0) + Math.max(0, 60 - k) * 40) / 10) * 10;
  return { rev, exp: Math.round(rev * (.6 + .07 * Math.sin(i * 1.7)) / 10) * 10 };
}
const dayData = k => k === 0 ? { rev: revenueToday(), exp: expensesToday() } : past(k);
const series = (n, off) => Array.from({ length: n }, (_, j) => dayData(off + n - 1 - j));
const sum = (a, k) => a.reduce((x, d) => x + d[k], 0);
function renderProfit() {
  if (!$('#profit-revenue')) return;
  const n = ui.days, cur = series(n, 0), prev = series(n, n);
  const rev = sum(cur, 'rev'), exp = sum(cur, 'exp'), net = rev - exp, mar = net / rev * 100;
  const pr = sum(prev, 'rev'), pe = sum(prev, 'exp'), pm = (pr - pe) / pr * 100;
  const note = (id, now, was, pts) => {
    const diff = pts ? now - was : (now - was) / was * 100, up = diff >= 0, el = $(id).nextElementSibling;
    el.innerHTML = `${pts ? '' : `<i class="fa-solid fa-arrow-${up ? 'up' : 'down'} btn-arrow-ne"></i>`}${pts ? (up ? '+' : '') + diff.toFixed(1) + ' pts' : Math.abs(diff).toFixed(1) + '%'} vs. previous ${n} days`;
  };
  $('#profit-revenue').textContent = peso(rev); $('#profit-expenses').textContent = peso(exp);
  $('#profit-net').textContent = peso(net); $('#profit-margin').textContent = mar.toFixed(1) + '%';
  note('#profit-revenue', rev, pr); note('#profit-expenses', exp, pe); note('#profit-net', net, pr - pe); note('#profit-margin', mar, pm, true);
  const bd = $('.btn-date'), from = new Date(Date.now() - (n - 1) * DAY);
  bd.innerHTML = `<i class="fa-regular fa-calendar"></i>${md(from)} – ${md(Date.now())}, ${new Date().getFullYear()}`;

  const mx = Math.max(5000, Math.ceil(Math.max(...cur.map(d => Math.max(d.rev, d.exp))) / 5000) * 5000);
  const path = k => cur.map((d, i) => `${i ? 'L' : 'M'}${(i / (n - 1) * 600).toFixed(1)} ${(199 - d[k] / mx * 198).toFixed(1)}`).join(' ');
  $('#chart-revenue').setAttribute('d', path('rev')); $('#chart-expenses').setAttribute('d', path('exp'));
  $('#chart-area').setAttribute('d', path('rev') + ' L600 199 L0 199 Z');
  $$('#revenue-chart .line-axis span').forEach((s, i) => s.textContent = kfmt(mx * (3 - i) / 3));
  $$('#revenue-chart .line-x span').forEach((s, j) => s.textContent = md(Date.now() - (n - 1 - Math.round(j * (n - 1) / 6)) * DAY));
  const rg = (rev - pr) / pr, eg = (exp - pe) / pe;
  $('.chart-note').innerHTML = `<i class="fa-solid fa-arrow-trend-up"></i>${rg >= eg ? 'Revenue is growing faster than expenses. That’s a lovely sign.' : 'Expenses are growing faster than revenue. Worth a closer look.'}`;

  const shares = [['Ingredients', .4, 'dot-blue'], ['Payroll', .3, 'dot-pinkline'], ['Rent', .2, 'dot-navy'], ['Utilities', .1, 'dot-periwinkle']];
  const dn = $('#expense-donut'); let acc = 0;
  ['--a', '--b', '--c', '--d'].forEach((v, i) => { acc += shares[i][1]; dn.style.setProperty(v, acc * 100 + '%'); });
  $('#expense-total').textContent = peso(exp);
  $('#expense-split').innerHTML = shares.map(([l, p, c]) => `<li><span class="dot ${c}"></span><span class="split-name">${l}</span><strong>${pesoS(exp * p)}</strong><em>${Math.round(p * 100)}%</em></li>`).join('');

  $('#ledger-table tbody').innerHTML = [...S.expenses].sort((a, b) => b.ts - a.ts).slice(0, 5).map(e => `<tr><td>${esc(e.desc)}</td><td class="muted">${esc(e.cat)}</td><td class="muted">${md(e.ts)}</td><td class="total">${peso(e.amount)}</td></tr>`).join('');
  const tr = revenueToday(), te = expensesToday(), tn = tr - te;
  $('#wins-net').textContent = peso(tn); $('#wins-revenue').textContent = pesoS(tr); $('#wins-expenses').textContent = pesoS(te);
  $('.wins-sub').textContent = `Net profit · ${md(Date.now())}`;
  $('.wins-foot').textContent = `A ${tr ? Math.round(tn / tr * 100) : 0}% margin today. Small moments, strong results.`;
}
function bindProfit() {
  if (!$('#profit-revenue')) return;
  $('.btn-date').onclick = () => { ui.days = { 7: 30, 30: 90, 90: 7 }[ui.days]; renderProfit(); };
  $('.panel-link[href="#"]').onclick = e => {
    e.preventDefault();
    modal('Add expense', `<label>Description<input id="ex-d" type="text" placeholder="e.g. Cleaning supplies"></label>
<label>Category<select id="ex-c"><option>Ingredients</option><option>Payroll</option><option>Rent</option><option>Utilities</option></select></label>
<label>Amount (₱)<input id="ex-a" type="number" min="1" step="0.01"></label>`,
      [{ label: 'Cancel' }, {
        label: 'Add expense', primary: true, onClick: b => {
          const desc = $('#ex-d', b).value.trim(), amount = parseFloat($('#ex-a', b).value);
          if (!desc || !(amount > 0)) { toast('Add a description and a valid amount'); return false; }
          S.expenses.push({ desc, cat: $('#ex-c', b).value, ts: Date.now(), amount }); commit(); toast('Expense added');
        }
      }]);
  };
  $('.greeting-actions .btn-primary').onclick = () => {
    const n = ui.days, cur = series(n, 0);
    const csv = 'Date,Revenue,Expenses,Net\n' + cur.map((d, i) => `${new Date(Date.now() - (n - 1 - i) * DAY).toISOString().slice(0, 10)},${d.rev},${d.exp},${d.rev - d.exp}`).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = `profit-report-${n}d.csv`; a.click();
    toast('Report exported');
  };
}

/* profile */
function initProfile() {
  if (!$('#first-name')) return;
  const ids = ['first-name', 'last-name', 'email', 'phone', 'language', 'timezone'];
  const defaults = ids.map(i => $('#' + i).value), sw = $$('.switch'), swDef = sw.map(s => s.checked);
  const apply = p => {
    if (!p) return;
    [p.first, p.last, p.email, p.phone, p.language, p.timezone].forEach((v, i) => $('#' + ids[i]).value = v);
    sw.forEach((s, i) => s.checked = p.toggles[i]);
    $('.profile-card h2').textContent = `${p.first} ${p.last}`; $('.profile-email').textContent = p.email;
    const av = $('.profile-avatar'); av.firstChild.textContent = initials(`${p.first} ${p.last}`) + '\n';
    if (p.photo) { av.style.backgroundImage = `url(${p.photo})`; av.style.backgroundSize = 'cover'; av.style.color = 'transparent'; }
  };
  apply(S.profile);
  $('.profile-actions .btn-outline').onclick = () => {
    if (S.profile) apply(S.profile);
    else { ids.forEach((id, i) => $('#' + id).value = defaults[i]); sw.forEach((s, i) => s.checked = swDef[i]); }
    toast('Changes discarded');
  };
  $('.profile-actions .btn-primary').onclick = () => {
    const v = ids.map(i => $('#' + i).value.trim());
    if (!v[0] || !v[1]) return toast('Please enter your first and last name');
    if (!/^\S+@\S+\.\S+$/.test(v[2])) return toast('Please enter a valid email address');
    S.profile = { first: v[0], last: v[1], email: v[2], phone: v[3], language: v[4], timezone: v[5], toggles: sw.map(s => s.checked), photo: (S.profile && S.profile.photo) || '' };
    apply(S.profile); commit(); chrome(); toast('Profile saved');
  };
  $$('.profile-tabs .tab').forEach((t, i) => t.onclick = () => { if (i) toast(`${t.textContent.trim()} is coming soon`); });
  const file = document.createElement('input'); file.type = 'file'; file.accept = 'image/*';
  file.onchange = () => {
    const f = file.files[0]; if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      const p = S.profile || { first: $('#first-name').value, last: $('#last-name').value, email: $('#email').value, phone: $('#phone').value, language: $('#language').value, timezone: $('#timezone').value, toggles: sw.map(s => s.checked) };
      p.photo = rd.result; S.profile = p; apply(p); commit(); toast('Photo updated');
    };
    rd.readAsDataURL(f);
  };
  $$('.avatar-cam,.profile-card .btn-block').forEach(b => b.onclick = () => file.click());
  $('.safe-row .btn').onclick = () => modal('Change password', `<label>Current password<input id="pw0" type="password"></label><label>New password<input id="pw1" type="password"></label><label>Confirm new password<input id="pw2" type="password"></label>`,
    [{ label: 'Cancel' }, {
      label: 'Update password', primary: true, onClick: b => {
        const n = $('#pw1', b).value;
        if (!$('#pw0', b).value) { toast('Enter your current password'); return false; }
        if (n.length < 8) { toast('New password needs at least 8 characters'); return false; }
        if (n !== $('#pw2', b).value) { toast('Passwords do not match'); return false; }
        $('.safe-row small').textContent = `Password last updated ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
        toast('Password updated');
      }
    }]);
}

/* boot  */
function refresh() {
  chrome(); renderIndex(); renderHome(); renderOrders(); renderMenu(); renderTables(); renderProfit();
}
(async function init() {
  S = await load();
  bindChrome(); bindOrders(); bindMenu(); bindTables(); bindProfit(); initProfile();
  refresh();
  setInterval(refresh, 30000);
})();
})();